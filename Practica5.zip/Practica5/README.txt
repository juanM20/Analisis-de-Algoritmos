Los archivos que se manejan tanto para lectura como para escritura
son de extensión .txt


Por favor coloque los archivos a procesar en el mismo directorio de los archivos 
LCS.py y runScript.py, ahí se guardarán también los archivos de resultado.


Ejecute el archivo runScript.py de la siguiente forma: 
python runScript.py numero_de_archivos

donde numero_de_archivos es un entero que indica cuantos archivos que contienen
dos cadenas a comparar serán procesados.


Posteriormente se pedirá ingresar el nombre de cada uno, por favor ingrese el NOMBRE 
DEL ARCHIVO SIN EXTESIÓN, por ejemplo:

Directorio 					Programa
EjercicioPrueba.txt			EjercicioPrueba


Después de haber ingresado todos los nombres, espere a que el programa principal LCS.py
termine de ejecutarse, se dará un mensaje de finalización y podrá consultar los archivos
de resultado con la infomración correspondiente al archivo procesado, estos nuevos
archivos tienen el nombre de aquel procesado seguido de la palabra "Resultado".


3CM1
Benítez Morales Manuel Emilio
Tellez Pérez Juan Manuel


